import cv2
import numpy as np
import pandas as pd
from pathlib import Path

INPUT_VIDEO = "clip_01.mp4"
Y_REF = 380                 # fixed horizontal axis from the reference image
OUTPUT_VIDEO = "annotated_lane_center.mp4"
OUTPUT_CSV = "center_points.csv"

def detect_lane(frame, y_ref=Y_REF):
    h, w = frame.shape[:2]

    # Canny Edge Detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)

    # Road ROI
    roi_mask = np.zeros_like(edges)
    polygon = np.array([[(0, h-5), (155, 95), (470, 95), (w, h-5)]], np.int32)
    cv2.fillPoly(roi_mask, polygon, 255)
    roi_edges = cv2.bitwise_and(edges, roi_mask)

    # Hough Line Transform
    lines = cv2.HoughLinesP(
        roi_edges, 1, np.pi/180,
        threshold=20, minLineLength=30, maxLineGap=25
    )

    left, right = [], []
    if lines is not None:
        for x1, y1, x2, y2 in lines[:, 0]:
            dx, dy = x2-x1, y2-y1
            if abs(dy) < 8:
                continue

            x_at_ref = x1 + (y_ref-y1)*dx/dy
            slope = dx/dy
            length = np.hypot(dx, dy)
            y_low, y_high = min(y1, y2), max(y1, y2)

            if slope < -0.25 and 0 <= x_at_ref <= 230 and y_low < y_ref+35 and y_high > 110:
                left.append((x_at_ref, length))

            if slope > 0.25 and 350 <= x_at_ref <= 620 and y_low < y_ref+35 and y_high > 110:
                right.append((x_at_ref, length))

    def marking_center(candidates):
        if not candidates:
            return None
        xs = np.array([x for x, _ in candidates])
        q20, q80 = np.percentile(xs, [20, 80])
        return float((q20+q80)/2 if q80-q20 > 10 else np.median(xs))

    lx = marking_center(left)
    rx = marking_center(right)
    cx = (lx+rx)/2 if lx is not None and rx is not None else None
    return lx, rx, cx

# Read video, call detect_lane() for every frame,
# draw the point (center_x, Y_REF), and save center_points.csv.
